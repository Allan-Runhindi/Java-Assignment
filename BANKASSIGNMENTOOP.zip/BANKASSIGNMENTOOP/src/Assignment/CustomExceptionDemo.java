package Assignment;

// Custom Exception Class
class MyCustomException extends Exception {
    public MyCustomException(String message) {
        super(message);
    }
}

public class CustomExceptionDemo {
    public static void main(String[] args) {
        try {
            // Call method that throws exception
            checkNumber(-10);  // Change this value to test
        } catch (MyCustomException e) {
            // Catch and display message
            System.out.println("Caught Exception: " + e.getMessage());
        }
    }

    // Method that throws custom exception
    public static void checkNumber(int num) throws MyCustomException {
        if (num < 0) {
            throw new MyCustomException("Number cannot be negative!");
        } else {
            System.out.println("Number is valid: " + num);
        }
    }
}

