package Assignment;

import java.util.*;
import java.util.stream.*;

public class DivisibleByFive {
    public static void main(String[] args) {
        // Given ArrayList
        List<Integer> numbers = Arrays.asList(1, 4, 5, 20, 30, 6);

        // Use stream to filter numbers divisible by 5
        List<Integer> divisibleByFive = numbers.stream()
                                               .filter(n -> n % 5 == 0)
                                               .collect(Collectors.toList());

        // Print the results
        System.out.println("Numbers divisible by 5: " + divisibleByFive);
    }
}

